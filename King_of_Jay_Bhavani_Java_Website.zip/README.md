# King of Jay Bhavani - Java Website

## Requirements
- Java 17+
- Maven

## Run
Open terminal inside this folder and run:

mvn spring-boot:run

Then open:
http://localhost:8080

The website includes:
- Aai Ekvira Mitra Mandal branding
- King of Jay Bhavani title
- Airoli / Navi Mumbai location
- Demo Sign In popup
- Notifications, Committee, Gallery sections

Note: The Sign In is currently a demo frontend login. A real secure login requires a database and password security.
